import React from "react";
import {
  FaArrowLeft,
  FaArrowRight,
  FaChevronDown,
  FaMicrophone,
  FaSearch,
  FaSearchLocation,
  FaSlidersH,
} from "react-icons/fa";
import "./main.css";
const main = () => {
  return (
    <div className="main">
      <div className="img">
        {/* <img
          src="https://images.unsplash.com/photo-1568605114967-8130f3a36994?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
          alt="image1"
        />
        <img
          src="https://images.unsplash.com/photo-1568605114967-8130f3a36994?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
          alt="image1"
        /> */}
      </div>
      <div className="search">
        <div className="search-options">
          <button className="search-option active">Buy</button>
          <button className="search-option">Rent</button>
          <button className="search-option">Sell</button>
        </div>
        <div className="search-bar">
          <input
            type="text"
            placeholder="Enter an address, city, neighborhood, or ZIP code."
            className="search-input"
          />
          <div className="buttons">
            <button className="button">
              <FaSearch />
            </button>
            <button className="button">
              <FaSearchLocation />
            </button>
            <button className="button">
              <FaMicrophone />
            </button>
          </div>
        </div>
      </div>

      {/* ------------------- Tranding area--------------------- */}

      <div className="trending">
        <div className="text">
          <h1>Tranding Area in Raipur</h1>
          <p>
            <span className="icon">
              <FaArrowLeft />
            </span>
            <span className="icon">
              <FaArrowRight />
            </span>
          </p>
        </div>
        <div className="areas">
          <div className="area">
            <img src="city.png" alt="image1" />
            <p>TELIBANDHA</p>
          </div>
          <div className="area">
            <img
              src="https://images.unsplash.com/photo-1568605114967-8130f3a36994?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
              alt="image1"
            />
            <p>MOWA SADDHU </p>
          </div>
          <div className="area">
            <img
              src="https://images.unsplash.com/photo-1568605114967-8130f3a36994?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
              alt="image1"
            />
            <p>NAYA RAIPUR</p>
          </div>
          <div className="area">
            <img
              src="https://images.unsplash.com/photo-1568605114967-8130f3a36994?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
              alt="image1"
            />
            <p>BHATAGOAN</p>
          </div>
          <div className="area">
            <img
              src="https://images.unsplash.com/photo-1568605114967-8130f3a36994?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
              alt="image1"
            />
            <p>AMLIDIH</p>
          </div>
          <div className="area">
            <img
              src="https://images.unsplash.com/photo-1568605114967-8130f3a36994?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
              alt="image1"
            />
            <p>SANTOSHI NAGAR</p>
          </div>
          <div className="area">
            <img
              src="https://images.unsplash.com/photo-1568605114967-8130f3a36994?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
              alt="image1"
            />
            <p>DDU NAGAR</p>
          </div>
        </div>
      </div>

      {/* ----------------------------Property---------------------------- */}
      <div className="property">
        <h1>Featured Property For Sale</h1>

        <div className="filters">
          <button className="filter active">All</button>
          <button className="filter">Residential</button>
          <button className="filter">Comercial</button>
          <button className="filter">Agricultural</button>
          <button className="filter">Industrial</button>
          <button className="filter">Semi-Commercial</button>
          <button className="filter">Residential</button>
          <button className="filter">
            <FaSlidersH className="icon" />
            Filter
          </button>
          <button className="filter">
            <FaChevronDown className="icon" /> Sort By
          </button>
        </div>
        <div className="cards"></div>
      </div>

      {/* ----------------------------Youtube Video---------------------------- */}
      <div></div>

      {/* ----------------------------Category---------------------------- */}
      <div></div>
      {/* ---------------------------Contact us ----------------------- */}
      <div></div>

      {/* ---------------------------Why Raipur Homes----------------------- */}
      <div className="whyhomes">
        <h1>Why Choose Raipur Homes ? </h1>
        <p>Ek Prayas to Fullfill Your Dreams </p>
        <div className="boxes">
          <div className="box">
            <i></i>
            <h2>Avoid Broker</h2>
            <p>
              No broker involvement by any kind of agent with us we will provide
              every possible lisiting with best deal.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default main;
